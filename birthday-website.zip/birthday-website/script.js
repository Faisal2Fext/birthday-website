// Countdown Timer
const birthdayDate = new Date("Jan 15, 2025 00:00:00").getTime();
const countdownTimer = setInterval(function() {
    const now = new Date().getTime();
    const timeLeft = birthdayDate - now;

    const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
    document.getElementById("countdown").innerHTML = `${days} days left until your birthday!`;
}, 1000);

// Search Functionality
function searchKeyword() {
    var input = document.getElementById("searchInput").value.toLowerCase();
    var resultText = document.getElementById("result");
    
    if (input === "who is little baby") {
        resultText.innerHTML = "<img src='images/little_baby.jpg'><p>This is you, my little baby!</p>";
    } else if (input === "best moment") {
        resultText.innerHTML = "<img src='images/best_moment.jpg'><p>Our unforgettable moment together!</p>";
    } else if (input === "love letter") {
        window.location.href = "loveletter.html";
    } else {
        resultText.innerHTML = "Try searching something even more special!";
    }
}
